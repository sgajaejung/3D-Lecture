#pragma once


const float MATH_PI = 3.1415f;


#include <windows.h>
#include <math.h>
#include <float.h>
#include "vector3.h"
#include "vector4.h"
#include "matrix44.h"
#include "quaternion.h"
