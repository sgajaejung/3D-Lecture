#pragma once


namespace graphic
{

	void RenderAxis();

	void RenderFPS(int timeDelta);

}
