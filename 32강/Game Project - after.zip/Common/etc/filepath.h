
#pragma once

namespace common
{

	std::string GetFilePathExceptFileName(const std::string &fileName);

}
