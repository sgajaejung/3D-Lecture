#pragma once

namespace common
{

	struct Vector2
	{
		float x, y;
	};

}
