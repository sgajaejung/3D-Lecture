#pragma once

namespace graphic
{

	// ���̷�Ʈ X �ʱ�ȭ.
	bool InitDirectX(HWND hWnd, const int width, const int height, OUT LPDIRECT3DDEVICE9 &pDevice);


}
