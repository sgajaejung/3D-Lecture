
#pragma once


#include "../Common/common.h"
#include "../Graphic/graphic.h"
#include "../Framework/framework.h"

using namespace common;

